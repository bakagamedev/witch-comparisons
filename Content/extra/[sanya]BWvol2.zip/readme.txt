To be used with https://nyaa.pantsu.cat/view/914069

Credit goes to [Eila] for the sub work, not sure if they were working on this volume themselves, but it's been a little while so here they are. Don't mean to undermine their work.